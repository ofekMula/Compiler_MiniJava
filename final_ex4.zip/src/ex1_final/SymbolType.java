package ex1_final;

public enum SymbolType {
    VAR(),
    METHOD(),
    CLASS();
}
