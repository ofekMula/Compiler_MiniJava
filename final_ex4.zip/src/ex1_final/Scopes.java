package ex1_final;

public enum Scopes {
    GlobalScope(),
    ClassScope(),
    MethodScope();
}
