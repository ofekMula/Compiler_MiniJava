package ast;

public abstract class Statement extends AstNode {
    public Statement() {
    }
}
