package ast;

public abstract class AstType extends AstNode {

    public AstType() {
    }
}
