package ast;

public abstract class Expr extends AstNode {
    public Expr() {
    }
}
