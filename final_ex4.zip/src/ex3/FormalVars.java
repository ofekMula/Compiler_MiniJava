package ex3;

public class FormalVars {
    String name;
    String type;

    FormalVars(String name, String type){
        this.name = name;
        this.type = type;
    }
}
