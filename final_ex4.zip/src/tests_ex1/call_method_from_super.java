//class Main {
//	public static void main(String[] args) {
//		System.out.println((new class1()).super_method());
//	}
//}
//
//class class1 {
//	int super_method() {
//		class1 e;
//		e = new class1();
//		return (e).super_method();
//	}
//
//}
//
//class class2 extends class1 {
//	int other_method() {
//		return (new class2()).super_method();
//	}
//
//}
//
