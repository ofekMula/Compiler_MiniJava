//class Main {
//	public static void main(String[] args) {
//		System.out.println(true);
//	}
//}
//
//class A {
//	int x;
//
//	int bar1() {
//		int new_x;
//		new_x = 5;
//		return new_x;
//	}
//
//	int bar2() {
//		x = 9;
//		return x;
//	}
//
//}
//
