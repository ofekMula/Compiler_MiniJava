//class Main {
//	public static void main(String[] args) {
//		System.out.println(true);
//	}
//}
//
//class A {
//	int bar(int x) {
//		x = 5;
//		return x;
//	}
//
//}
//
