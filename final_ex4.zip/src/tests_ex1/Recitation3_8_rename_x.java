//class Main {
//	public static void main(String[] args) {
//		System.out.println(true);
//	}
//}
//
//class A {
//	int new_x;
//
//	int bar1() {
//		int x;
//		x = 5;
//		return x;
//	}
//
//	int bar2() {
//		new_x = 9;
//		return new_x;
//	}
//
//}
//
