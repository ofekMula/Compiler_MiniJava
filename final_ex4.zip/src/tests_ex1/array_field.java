//class Main {
//    public static void main(String[] args) {
//        System.out.println(true);
//    }
//}
//
//class A {
//    int[] arr;
//
//}
//
//class B extends A {
//    boolean bar1() {
//        int[] arr;
//        return false;
//    }
//
//}
//
