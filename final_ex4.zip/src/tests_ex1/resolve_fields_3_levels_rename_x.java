//class Main {
//	public static void main(String[] args) {
//		System.out.println(true);
//	}
//}
//
//class class1 {
//	int new_x;
//
//}
//
//class class2 extends class1 {
//	int y;
//
//}
//
//class class3 extends class2 {
//	int bar1() {
//		int x;
//		int y;
//		x = 5;
//		return y;
//	}
//
//	int bar2() {
//		new_x = 1;
//		y = 2;
//		return (new_x) + (y);
//	}
//
//}
//
