//class Main {
//	public static void main(String[] args) {
//		System.out.println((new class1()).override_method());
//	}
//}
//
//class class1 {
//	int override_method() {   <=====
//		class1 e;
//		e = new class1();
//		return (e).override_method();  <=====
//	}
//
//}
//
//class class2 extends class1 {
//	int override_method() {  <=====
//		return (new class2()).override_method();  <=====
//	}
//
//}
//
//class class3 extends class1 {
//	int override_method() {  <=====
//		return (new class2()).override_method();  <=====
//	}
//
//}
//
