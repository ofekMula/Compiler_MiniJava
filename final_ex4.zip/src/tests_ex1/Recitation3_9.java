//class Main {
//	public static void main(String[] args) {
//		System.out.println(true);
//	}
//}
//
//class O {
//	int x;
//
//}
//
//class A extends O {
//	int bar1() {
//		int x;
//		x = 5;
//		return x;
//	}
//
//	int bar2() {
//		x = 9;
//		return x;
//	}
//
//}
//
