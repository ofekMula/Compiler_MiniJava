//class Main {
//    public static void main(String[] args) {
//        System.out.println(true);
//    }
//}
//
//class A {
//    boolean flag;
//
//}
//
//class B extends A {
//    boolean bar1() {
//        boolean flag;
//        flag = true;
//        return flag;
//    }
//
//    boolean bar2() {
//        if (flag)
//            flag = false;
//        else
//            flag = true;
//        return flag;
//    }
//
//}
//
