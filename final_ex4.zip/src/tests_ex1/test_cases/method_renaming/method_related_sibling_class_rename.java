//class Main {
//	public static void main(String[] args) {
//		System.out.println(1);
//	}
//}
//
//class Shared {
//	int renamedMethod() {
//		return 1;
//	}
//
//}
//
//class A extends Shared {
//}
//
//class B extends A {
//	int renamedMethod() {
//		return 2;
//	}
//
//}
//
//class C extends A {
//	int renamedMethod() {
//		return 3;
//	}
//
//}
//
