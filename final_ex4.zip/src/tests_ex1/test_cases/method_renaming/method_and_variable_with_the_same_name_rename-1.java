//class Main {
//	public static void main(String[] args) {
//		System.out.println(1);
//	}
//}
//
//class Shared {
//	int theThing;
//
//	int renamedThing() {
//		return theThing;
//	}
//
//}
//
//class A extends Shared {
//}
//
//class B extends A {
//	int renamedThing() {
//		return theThing;
//	}
//
//}
//
//class C extends A {
//	int renamedThing() {
//		return theThing;
//	}
//
//}
//
//class D extends A {
//	int renamedThing() {
//		int theThing;
//		return theThing;
//	}
//
//}
//
//class E extends A {
//	int renamedThing(int theThing) {
//		return theThing;
//	}
//
//}
//
