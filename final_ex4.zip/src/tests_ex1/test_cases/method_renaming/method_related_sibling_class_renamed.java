//package tests_ex1.test_cases.method_renaming;
//
//class Main {
//    public static void main(String[] args) {
//        System.out.println(1);
//    }
//}
//
//class Shared {
//    public int renamedMethod() {
//        return 1;
//    }
//}
//
//class A extends Shared { }
//
//class B extends A {
//    public int renamedMethod() {
//        return 2;
//    }
//}
//
//class C extends A {
//    public int renamedMethod() {
//        return 3;
//    }
//}
