package ex2.ast;

public abstract class Statement extends AstNode {
    public Statement() {
    }
}
