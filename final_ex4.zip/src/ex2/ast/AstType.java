package ex2.ast;

public abstract class AstType extends AstNode {

    public AstType() {
    }
}
