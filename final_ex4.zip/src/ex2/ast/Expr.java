package ex2.ast;

public abstract class Expr extends AstNode {
    public Expr() {
    }
}
